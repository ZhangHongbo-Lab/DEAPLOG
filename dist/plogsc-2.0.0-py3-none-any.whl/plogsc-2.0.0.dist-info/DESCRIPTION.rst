# PLOGSCD(Pseudotemporal Locating and Ordering of Gene by Single-Cell Data)
PLOGSCD is a tool to identify marker genes for cell clusters, calculate the pseudotime of genes and profile genes map accoding to cell map. It can be directly used in the [scanpy](https://scanpy.readthedocs.io/en/latest/) workflow. 

