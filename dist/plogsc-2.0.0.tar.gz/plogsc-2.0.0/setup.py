import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="plogsc", 
    version="2.0.0",
    author="Bao Zhang",
    author_email="zhangbao1991@hotmail.com",
    description="toolkit for single cell transcriptome analysis",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ZhangHongbo-Lab/PLOGS",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3.6",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)