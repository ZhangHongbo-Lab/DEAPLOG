# DEAPLOG(Differentially Expression Analysis and Pseudotemporal Locating and Ordering of Gene by Single-cell RNA-seq data)

DEAPLOG is a tool to perform differentially expression analysis for cell clusters and other conditions, calculate the pseudotime of genes and profile genes coordinates accoding to the embedding coordinates of cells.
